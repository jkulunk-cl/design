import {Component} from '@angular/core';

@Component({
    selector: 'app-data-table',
    templateUrl: 'datatable.component.html'

})
export class DataTableComponent {}
