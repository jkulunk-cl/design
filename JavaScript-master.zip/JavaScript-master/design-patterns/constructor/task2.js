// build constructor
var Task = function(name){
    this.name = name;
    this.completed = false;
};

// building a prototype and moving methods to it
//CLASSNAME.prototype.METHODNAME = function (arguments) {...

Task.prototype.complete = function(){
    console.log('completing task ' + this.name);
    this.completed = true;

};

Task.prototype.save = function(){
    console.log('saving task ' + this.name);
};

// create instances (copies) of obj
// each has a separate THIS
var task1 = new Task('constructor demo');
var task2 = new Task('module demo');
var task3 = new Task('singleton demo');
var task4 = new Task('prototype demo');

// usage
task1.complete();
task2.save();
task3.save();
task4.save();