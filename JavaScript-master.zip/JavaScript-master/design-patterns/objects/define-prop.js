var task = {
    title: 'The Title',
    desc: 'Description'
};

Object.defineProperty(task, 'toString', {
    value: function(){
        return this.title + ' ' + this.desc;
    },
    writable: true,
    enumerable: false,  // if false then doesn't show in keys list
    configurable: true  // allows for redefining these props
});

task.toString = 'breaking method';

console.log(Object.keys(task));
