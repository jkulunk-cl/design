var task = {
    title: 'title',
    desc: 'desc'
};


task.toString = function () {
    return task.title;
}

console.log(task.toString());

