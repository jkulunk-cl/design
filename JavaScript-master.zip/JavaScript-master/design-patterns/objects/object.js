var obj = {};

var obj2 = Object.create(Object.prototype);
// for inheritance

var obj3 = new Object();
// out of favor but ok
// with class operator

//assiging var

obj.param = 'new value'; // dot notation

obj['param'] = 'new value'; // bracket notation

obj[variableName] = 'new value'; // can use with var as param

