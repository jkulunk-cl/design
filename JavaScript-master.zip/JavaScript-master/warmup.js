var findNodes = function (){
    var i = 100,
    nodes = [],
    found;

    while (i){
        i -= 1;
        found = 'sub task ' + i;
        nodes.push(found);
    }
    
    console.log(nodes);
    return nodes;
};

findNodes();