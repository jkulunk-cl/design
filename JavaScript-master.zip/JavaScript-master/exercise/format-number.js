function formatNumber(number) {
    var str = number.toString();
    var strArr = str.split('');
    var newStrArr = [];

    strArr.reverse();

    for (var i = 0; i < strArr.length; i++) {

        if ((i % 3 === 0) && (i !== 0)) {
            newStrArr.push(',');
        }
        newStrArr.push(strArr[i]);
    }

    newStrArr.reverse();
    str = newStrArr.join('');

    console.log(str);

    return str;
}

//formatNumber(1234123);

// needs work
function format2(number){
    var str = number.toString();
    var newStr = '';
    var temp = '';
    var l = str.length;
    var i = l;

    while(i > 0){
        newStr = str.slice(i-3,i) + ',' + newStr;

        i -= 3;
        console.log('str: ' + str + ' newStr: ' + newStr + ' i: ' + i);
    }

    //newStr = str.slice() + ',' + newStr;
    console.log(newStr);
    return str;
}

// format2(12345678);

var format3 = function(x){
    var str = x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    console.log(str);
}

format3(12332112312);

/*
Like the comments,�reading about regular expressions�would be the most beneficial for you (in the long run).
Breaking down this specific Regular Expression is as such:
The�\B�tells it to look only within a word boundary (meaning it can't be part of another type of word - it
can't be�b123412b123, but only accept what it finds if it stands alone -�123456,�a 123456 w
Then a lookahead�(?=�tells it to find whatever is in the group (until it reaches the matching closing parenthesis)
and only return if it is found as a whole, it is also making sure the replacement is done in reverse because it is
looking as far ahead as to the end of the string. ?:�tells it to look for the following match but not create a
backreference (a term in regular expressions) \d{3}�looks for 3 digits in a row. Then the�+�afterwards marks that
the 3 digits (wrapped in parentheses to make sure the rule is treated as one block like so -�(\d{3})+) pattern can
repeat (3 digits, 6, 9, etc). The last�(?!\d)�looks for yet another digit but�excluding it, making sure the digits
are in groups of 3 and not followed by digits that are not in groups of 3.

So basically it looks for 1 or more groups of 3 digits, telling the RegEx�not�to return the matched digits (because
they're ignored with�?:) therefore returning only the part of the match that's not nothing - it's returning�\B, and
that's what's being replaced. So effectively it only replaces full groups of 3, starting from the end of the string,
causing it to turn�3333333�into�3,333,333.


Also https://www.w3schools.com/Jsref/jsref_obj_regexp.asp

*/
