foo = (params) => 'returns';

