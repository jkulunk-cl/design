var repo = function(){

    var called = 0;


    var save = function(task){
        called++;
        console.log("saving: " + task + " called: " + called + "x");
    }

    console.log("newing up task repo");;

    return {
        save: save
    }
}

module.exports = repo();
// () executes function in module.exports.
// effectively have created singleton in repo.
// alternate using 'new' keyword
//     module.exports = new repo;