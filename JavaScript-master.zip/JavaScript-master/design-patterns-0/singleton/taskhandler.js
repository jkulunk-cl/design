var myrepo = require('./repo');

var taskHandler = function(){
    return {
        save: function(){
            myrepo.save('from taskHandler');
        }
    }
}

module.exports = taskHandler();