// asynchronous execution pattern

// this does not work!!

var result = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 171, 81, 9, 20];

var buffer = function (items, iterFn, callback) { // args: item arr, iteration fn, after complete fn
    var i = 0, len = items.length;

    setTimeout(function () {
        var result;

        for (var start = +new Date; i < len && result !== false && ((+new Date) - start < 50); i++) {  // '+new Date' returns number of miliseconds instead of current date
            result = iterFn.call(items[i], items[i], i);
        }

        if (i < len && result !== false) {
            setTimeout(arguments.callee, 20);
        } else {
            callback(items);
        }

    }, 20);
};


// implemented as update to DOM
/*
$.get('/home/data', function (result) {
    var html = '';

    buffer(result, function (item) {        // args: item arr, iteration fn, after complete fn
        html += '<li>' + result[i] + '</li>';
    }, function () {
        $('ul').append(html);
    });
    
});
*/

var html = '';

buffer(result, function (item) {        // args: item arr, iteration fn, after complete fn
    html += '<li>' + result[i] + '</li>';
}, function () {
    console.log(html);
});