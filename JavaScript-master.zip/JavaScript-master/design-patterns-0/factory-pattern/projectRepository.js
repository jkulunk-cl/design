var repo = function(){
    
    var db = {};

    var get = function(id){
        console.log('getting task from project repo:' + id);
        return {
            name: 'new task from project repo'
        }
    };

    var save = function(task){
        console.log('saving to project repo: ' + task.name);
    };

    console.log('newing up task in project repo');
    return {
        get: get,
        save: save
    }

    
}

module.exports = repo;