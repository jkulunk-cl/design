var repo = function(){
    
    var db = {};

    var get = function(id){
        console.log('getting task from user repo: ' + id);
        return {
            name: 'new task from user repo'
        }
    };

    var save = function(task){
        console.log('saving task to user repo: ' + task.name);
    };

    console.log('newing up task in user repo');
    return {
        get: get,
        save: save
    }

    
}

module.exports = repo;