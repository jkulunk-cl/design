var repo = function(){
    
    var db = {};

    var get = function(id){
        console.log('getting task from task repo: ' + id);
        return {
            name: 'new task from task repo'
        }
    };

    var save = function(task){
        console.log('saving task to task repo:  ' + task.name);
    };

    console.log('newing up task in task repo');
    return {
        get: get,
        save: save
    }


}

module.exports = repo;