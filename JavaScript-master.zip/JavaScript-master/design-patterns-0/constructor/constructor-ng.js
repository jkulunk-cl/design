(function () {
    var app = angular.module('taskManager');

    app.factory('Task', function () {

        var Task = function (data) {
            this.name = data.name;
            this.completed = data.completed;
        }

        Task.prototype.complete = function () {
            this.completed = true;
            console.log('completed ' + this.name);
        };

        Task.prototype.save = function () {
            console.log('saved ' + this.name);
        };

        return Task;
    })


}());