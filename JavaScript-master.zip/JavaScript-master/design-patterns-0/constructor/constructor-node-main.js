// inject dependency
var Task = require('./constructor-node-declaration');

var task1 = new Task('task 1');
var task2 = new Task('task 2');
var task3 = new Task('task 3');
var task4 = new Task('task 4');

task1.complete();
task2.save();
task3.save();
task4.save();