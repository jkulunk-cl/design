//constructor declarations
var Task = function (name) {
    this.name = name;
    this.completed = false;

};

// prototype - links new objects to constructor
// this way the complete and save functions are only created once
Task.prototype.complete = function () {
    this.completed = true;
    console.log('completed ' + this.name);

};

Task.prototype.save = function () {
    console.log('saved ' + this.name);

};

module.exports = Task;