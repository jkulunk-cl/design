﻿# Practical Design Patterns in JavaScript
Pluralsight Course

## Creational design patterns
- constructor patterns
- module pattern
  - grouping of like methods
- factory pattern
- singleton pattern
 
### Structural pattern
- decorator
- facade
- flyweight
	
### Behavioral pattern
- how obj relate
- command pattern
- mediator
- observer
 
### Module Pattern
A way to encapsulate methods. Creating a sort of toolbox of functions.
Like service calls or http calls.
- an object literal of key/value pairs.
- Each key is a method within a module. like Module.getData()
- Revealing module pattern.
- Move methods out of return. Access thru api.

### Factory Pattern
- to simplify object creation
- creating different types of objects based on need
- repository creation. repo factory

### Singleton Pattern
- to restrict an object to one instance of that object accross app
- remembers last use. hands back same instance

## Structural design patterns
- concerned with how objects are made up
- simplify relationships between objects
- deals with relationship of objects
- extends functionality
- simplifies functionality
- decorator pattern
- flyaway/facade pattern

### Decorator pattern
- adds new functionality to existing object
- without being intrusive
- more complete inheritance
- wraps an object
- protects existing object
- allows extended functionality

### Facade pattern
- provides a simplified interface to a complicated system
- hides complexity of backend from us
- simplifies the interface
- a la jquery for javascript / dom

### Flyweight pattern
- conserves memory by sharing portions of an object between objects
- tasks have lots of common data
- share data across objects
- smaller memory footprint
- only useful if have large numbers of objects
- subset of a task

## Behavioral Design patterns
- concerned with the assignment of responsibilities between objects and how the communicate
- help obects qooperate
- deasl with obj responsibility
- assign obj heirarchy
- encapsulate requests, alter request

### Observer pattern
- allows for a collection of obj to watch another object and notify of changes
- allows for a loosely coupled system
- one obj is the focus
- group of obj that watch for changes
- observers. Going to watch for changes
- subjects. the obj being watched
- observer doesn't know much about subject, but subject knew about observers

### Mediator patterns
- control communication between objects so neither object has to be coupled to the other
- allows for loosly coupled system
- one obj manages all communication
- many to many relationships
- several obj publishing and notifying all at once. managed through mediator

### Command pattern
- encapsulates the calling of a method as an object
- fully decoupling execution from implementation
- ex. calling Service.save . Service has a Save method.
- allows for less fragile implementation
- supports undo operations. stor and revert state
- supports auditing, logging of operations
