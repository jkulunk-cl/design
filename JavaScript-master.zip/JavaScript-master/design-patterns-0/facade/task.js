var Task = function(data){
    this.name = data.name;
    this.priority = data.priority;
    this.project = data.project;
    this.user = data.user;
    this.completed = data.completed;
};

var TaskService = function(){
    return {
        complete: function(task){
            task.completed = true;
            console.log('completed task: ' + task.name);
        },
        setCompleteData: function(task){
            task.completedDate = new Date();
            console.log('completed task: ' + task.name + ' completed date: ' + task.completedDate)
        },
        notifyCompletion: function(task, user){
            console.log('notify: ' + user + ' completed task: ' + task.name);
        },
        save: function(task){
            console.log('saving task: ' + task.name);
        }
    }
}();

// facade wrapper
var TaskServiceWrapper = function(){

    var completeAndNotify = function(task){

        TaskService.complete(myTask);

        if(myTask.completed == true){
            TaskService.setCompleteData(myTask);
            TaskService.notifyCompletion(myTask,myTask.user);
            TaskService.save(myTask);
        }
    }

    return {
        completeAndNotify: completeAndNotify
    }
}();

var myTask = new Task({
    name: 'my task',
    priority: 1,
    project: 'courses',
    user: 'john',
    completed: false
});


// main
TaskServiceWrapper.completeAndNotify(myTask);

console.log(myTask);