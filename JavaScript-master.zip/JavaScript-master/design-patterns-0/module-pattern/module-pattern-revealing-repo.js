// alternate method using the revealing module pattern

var repo = function () {

    // Method within a Module
    var get = function (id) {
        console.log('(revealing pattern) getting task ' + id);
        return {
            name: 'task from db'
        }
    };

    var save = function (task) {
        console.log('saving to db ' + task.name);
    };


    return {
        // revealing module 
        get: get,
        save: save
    }
}

module.exports = repo();