var repo = function () {
    return {
        // Method within a Module
        get: function (id) {
            console.log('getting task ' + id);
            return {
                name: 'task from db'
            }
        },
        save: function (task) {
            console.log('saving to db ' + task.name );
        }
    }
}

module.exports = repo();