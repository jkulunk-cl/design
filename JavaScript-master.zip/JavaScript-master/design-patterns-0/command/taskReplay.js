// simuate having a connection issue.
// resends the tasks

var repo = {
    tasks: {},
    commands: [],
    get: function(id){
        consoel.log('getting task: ' + id);
        return {
            name: 'new task from db'
        }
    },
    save: function(task){
        repo.tasks[task.id] = task;
        console.log('saving task: ' + task.name);
    },
    replay: function() { // simulating resending of task
        for (var i = 0; i < repo.commands.length; i++){
            var command = repo.commands[i];
            repo.executeNoLog(command.name, command.obj);
        }
    }
};

repo.executeNoLog = function(name){
    var args = Array.prototype.slice.call(arguments,1);
    if(repo[name]){
        return repo[name].apply(repo, args);
    }
};

repo.execute = function(name){
    var args = Array.prototype.slice.call(arguments,1);

    repo.commands.push({
        name: name,
        obj: args[0]
    });

    if(repo[name]){
        return repo[name].apply(repo,args);
    }

    return false // otherwise exit
};

// run it
repo.execute('save', {
    id:1,
    name: 'task 1',
    completed: false
});

repo.execute('save', {
    id:2,
    name: 'task 2',
    completed: false
});

repo.execute('save', {
    id:3,
    name: 'task 3',
    completed: false
});

repo.execute('save', {
    id:4,
    name: 'task 4',
    completed: false
});

console.log(repo.tasks);

repo.tasks = {}; // simulate loosing task data
console.log(repo.tasks);

repo.replay(); // resend all tasks
console.log(repo.tasks);

