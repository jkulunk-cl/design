var Task = require('./task');

// observers 1
var notificationService = function(){
    var message = 'notifying ';
    this.update = function(task){
        console.log(message + task.user + ' for task ' + task.name);
    }
};

// observer 2
var loggingService = function(){
    var message = 'logging ';
    this.update = function(task){
        console.log(message + task.user + ' for task ' + task.name);
    }
};

// observer 3
var auditingService = function(){
    var message = 'auditing ';
    this.update = function(task){
        console.log(message + task.user + ' for task ' + task.name);
    }
};

function ObserverList(){
    this.obsererList = [];
}

ObserverList.prototype.add = function(obj){
    return this.obsererList.push(obj);
};

ObserverList.prototype.get = function(index){
    if(index > - 1 && index < this.obsererList.length){
        return this.obsererList[index];
    }
};

ObserverList.prototype.count = function(){
    return this.obsererList.length;
}

ObserverList.prototype.removeAt = function(index){
    this.obsererList.splice(index,1);
};

ObserverList.prototype.indexOf = function(obj, startIndex){
    var i = startIndex;

    while(i < this.obsererList.length){
        if(this.obsererList[i] === obj){
            return i;
        }
        i++;
    }
    return -1;
};

var ObservableTask = function(data){
    Task.call(this,data) //passing this to task with param
    this.observers = new ObserverList(); // add to task, observers list. newing up an empty array
}

ObservableTask.prototype.addObserver = function(observer){
    this.observers.add(observer);
    // pass in observer and then add to observer list
    // run when we do notify
};

ObservableTask.prototype.removeObserver = function(observer){
    this.observers.removeAt(this.observers.indexOf(observer,0));    
}

ObservableTask.prototype.notify = function(context){
    var observerCount = this.observers.count();

    for(var i=0; i < observerCount; i++){
        this.observers.get(i)(context);
    }
};

ObservableTask.prototype.save = function(){
    Task.prototype.save.call(this);
    this.notify(this); // sending notification
};


var mediator = (function(){
    var channels = {};

    var subscribe = function(channel, context, func){ // func = callback function
        if (!mediator.channels[channel]){ 
            mediator.channels[channel] = [];
        }
        mediator.channels[channel].push({ // adds to channels obj. not an array.
            context: context,
            func: func
        });
    };

    var publish = function(channel){
        if(!this.channels[channel]){
            return false
        }

        var args = Array.prototype.slice.call(arguments,1);

        for (var i = 0; i < mediator.channels[channel].length; i++){
            var sub = mediator.channels[channel][i];
            sub.func.apply(sub.context, args);
        }

    };

    return { // revealing module pattern
        channels: {},
        subscribe: subscribe,
        publish: publish
        
    }
}());

var task1 = new ObservableTask({
    name: 'create a demo for mediator',
    user: 'john'
});

var not = new notificationService();
var ls = new loggingService();
var audit = new auditingService();

mediator.subscribe('complete', not, not.update);
mediator.subscribe('complete', ls, ls.update);
mediator.subscribe('complete', audit, audit.update);


// run it
task1.complete = function(){
    mediator.publish('complete', this);
    Task.prototype.complete.call(this);
}
task1.complete();