'use strict';

var price = 5.99, qty = 10;
var productView = {
    price,
    qty,
    'calculate value'(){
        return this.price * this.qty
    }
};

console.log(productView['calculate value']());

//
var field = 'dynamicField';
var price = 5.99;
var productView = {
    [field]: price
};

console.log(productView);

//
var field = 'dynamicField';
var price = 5.99;
var productView = {
    [field + '-001']: price
};

console.log(productView);

//
var method = 'doIt';
var productView = {
    [method + '-001'](){
        console.log('in method');
    }
};

productView['doIt-001']();

//
var ident = 'productId';
var productView = {
    get [ident] () {
        return true;
    },
    set [ident] (value) {

    }
};

console.log(productView.productId);