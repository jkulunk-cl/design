'use strict';

var categories = ['red', 'green', 'blue'];
for (var item of categories){
    console.log(item);
}

//
var categories = [,,];
for (var item of categories){
    console.log(item);
}

//
var codes = 'abcdf';
var count = 0;
for (var code of codes){
    count++;
}

console.log(count);