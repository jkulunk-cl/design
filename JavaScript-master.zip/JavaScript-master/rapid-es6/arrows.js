// arrow functions: input params => returns
'use strict';

var invoice = {
    number: 123,
    process: () => console.log(this)    
};

invoice.process();