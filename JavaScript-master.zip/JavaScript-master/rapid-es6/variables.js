'use strict';

const pct = 100;

if (pct){
    const pct = 10;
}

console.log(pct);

