var Gadget = (function () {
    // static var
    var counter = 0,
        NewGadget;

    // constructor
    NewGadget = function () {
        counter += 1;
    };

    // privileged method
    NewGadget.prototype.getLastId = function () {
        return counter;
    };

    // overwrite constructor
    return NewGadget;

}()); // immediate function iffe

var out;

var iphone = new Gadget();
out = iphone.getLastId();

console.log(out);

var ipod = new Gadget();
out = ipod.getLastId();

console.log(out);

var ipad = new Gadget();
out = ipad.getLastId();

console.log(out);
