var person = {
    first: 'amy',
    last: 'adams',
    full: function(){
        return this.first + ' ' + this.last;
    }
}

var out = person.hasOwnProperty('first');
console.log(out);