# Javascript Patterns
O'Reilly

# Object creation patterns
## Sandbox pattern
## Static Members
- static properties and methods are those that don't change from one instance to another
- ex. max() of MathUtils like MathUtils.max(3,5)

### public static members
- constructor gadget, static method isShiny, instance setPrice.
- method isShiny is static

### private state members
- shared by all objects created with same constructor fun
- not accessable outside the constructor
- ex. Container is private static prop in the constructor Gadget
- returned fun value assigned to Gadget, becomes new constructor
- the new gadget constructor inrements and logs the private var counter
- counter var is shared with each instance
- this static prop becomes an ID for each object created with gadget constructor
- exposed with pridileged method getLastId. Access the static private prop

## Object Constants
