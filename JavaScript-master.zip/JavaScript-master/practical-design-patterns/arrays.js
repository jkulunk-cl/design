var arr1 = [0,1,2,3];
var arr2 = [4,5,6,7];
var arr3 = [8,9,10];
//delete numArr[2];

//numArr.splice(2,1);





// var str = arr1.join('');
// console.log(str);

arr1 = arr1.concat(arr2);

arr1.push(11);
arr1.reverse();
arr1.shift();
arr1.pop();
arr1 = arr1.slice(1,5);
arr1.sort();

arr1.splice(1,1,'12');
arr1.unshift('13');

for (var i = 0; i < arr1.length; i++){ 
    console.log(arr1[i]);
}