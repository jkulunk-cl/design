var out;

// constructor
var Gadget = function (price) {
    this.price = price;
};

// static method
Gadget.isShiny = function () {
    var msg = "it's shiny";

    if (this instanceof Gadget) {
        // called non-statically
        msg += " and costs $" + this.price;
    }

    return msg;
};

// method added to proto
Gadget.prototype.isShiny = function (price) {
    return Gadget.isShiny.call(this);
};

// test static method call
out = Gadget.isShiny();

console.log(out);

// test instance, nonstatic call
var a = new Gadget("499");
out = a.isShiny();

console.log(out);