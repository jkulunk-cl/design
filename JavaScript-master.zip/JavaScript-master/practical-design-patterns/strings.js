var person = {
    first: 'amy',
    last: 'adams',
    full: function(){
        return this.first + ' ' + this.last;
    }       
}

var fullName = person.full();

var initial = fullName.charAt(0);

var result = fullName.indexOf('adams');

var newName = fullName.replace('adams', 'mcadams')

var newName = newName.slice(6);
console.log(newName);