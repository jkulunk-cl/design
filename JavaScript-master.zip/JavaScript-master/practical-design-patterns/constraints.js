var constant = (function(){
    var constants = {};
    ownProp = Object.prototype.hasOwnProperty,
    allowed = {
        string:1,
        number: 1,
        boolean: 1
    },
    prefix = (Math.random() + '_').slice(2);
    return {
        set: function (name, value){
            if(this.isDefined(name)){
                return false;
            }
            
            if(!ownProp.call(allowed, typeof value)){
                return false;
            }

            constants[prefix + name] = value;
            return true;
        },
        isDefined: function(name){
            return ownProp.call(constants, prefix + name);
        },
        get: function(name){
            if(this.isDefined(name)){
                return constants[prefix + name];
            }
            return null;
            
        }
        
    };
}());

// is defined
var out;
out = constant.isDefined('max_width');
console.log(out);

// define
out = constant.set('max_width', 480);
console.log(out);

// recheck
out = constant.isDefined('max_width');
console.log(out);

// check value
out = constant.get('max_width');
console.log(out);