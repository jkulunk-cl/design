var serial = function(){
    var prefix = '';
    var seq = 0;
    return {
        setPrefix: function(p){
            prefix = String(p);
        },
        setSeq: function(s){
            seq = s;
        },
        gen: function(){
            var result = prefix + seq;
            seq++;
            return result;

        }
    };
};

var seqer = serial();
seqer.setPrefix('Q');
seqer.setSeq(1000);
var unique = seqer.gen();

console.log(unique);