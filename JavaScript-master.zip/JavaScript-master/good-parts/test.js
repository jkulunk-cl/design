// problem
/* const arr = [10,12,15,21];
for (var i = 0; i < arr.length; i++){
    
    console.log('i:' + i + ' arr.length:' + arr.length);

    setTimeout(function(){
        console.log('index: ' + i + ' element: ' + arr[i]);
    }, 3000);
} */


// solution 1
// pass in var i so that each function has access to the index
/* const arr = [10,12,15,21];
for (var i = 0; i < arr.length; i++){
    setTimeout(function(j){
        return function(){
            console.log('index: ' + j + ' element: ' + arr[j]);
        }
    }(i), 3000);
} */

// solution 2
// use ES6 'let' to create a new binding every time function is called
/* const arr = [10,12,15,21];
for(let i = 0; i < arr.length; i++){
    setTimeout(function(){
        console.log('index: ' + i + ' element: ' + arr[i]);
    }, 3000);
} */

const arr = [10,12,15,21];
for (var i = 0; i < arr.length; i++){
    
    console.log('i:' + i + ' arr.length:' + arr.length);

    setTimeout(function(j){
        return function(){
            console.log('index: ' + j + ' element: ' + arr[j]);
        }
        
    }(i), 3000);
} 