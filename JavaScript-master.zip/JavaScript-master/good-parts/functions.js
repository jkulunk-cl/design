// method

var myObject = {
    value: 0,
    increment: function(inc){
        this.value += typeof inc === 'number' ? inc : 1;
        console.log(this.value);
    }
    
};

myObject.increment();
myObject.increment(2);

// constructor
var Quo = function(string){
    this.status = string;
}

Quo.prototype.getStatus = function(){
    return this.status;
}

var myQuo = new Quo('what?');
console.log(myQuo.getStatus());

// apply
var add = function(a,b){
    return a + b;
}
var array = [3,4];
var sum = add.apply(null,array);

var statusObject = {
    status: 'ok'
};

var status = Quo.prototype.getStatus.apply(statusObject);
console.log(status);

// exceptions
var add2 = function (a,b) {

    if(typeof a !== 'number' || typeof b !== 'number'){
        throw {
            name: 'type error',
            message: 'not a number'
        };
    }
    return a + b;
}

var tryIt = function() {
    try {
        add2(3,'seven');
    } catch(err){
        console.log(err.name + ': ' + err.message );
    }
}

tryIt();

// recursion
function factorial(n){
    if(n === 1){
        return 1;
    }
    return n * factorial(n - 1);
}

var result = factorial(3);
console.log(result);