var myObject = (function(){
    var value = 0;

    return {
        increment: function(inc){
            value += typeof inc === 'number' ? inc : 1;
        },
        getValue: function(){
            return value;
        }
    };
}());


// ex 2
var quo = function (status){
    return {
        get_status: function(){
            return status;
        }
    };
};
// new quo object
var myQuo = quo("amazing");

// new obj has access to method in quo. closure.
console.log(myQuo.get_status());


// ex 3
// With closure, the step fun executes and returns but is set to run again in 100ms
// Eventhough step had ended and runs again it still has access to the value of Level.
// Var level continues to live as long as needed within Fade's inner functions.
// Inner fun has access to actual variables of outer fun. Not copies.
var fade = function(node){
    var backgroundColor;
    var level = 1;

    var step = function(){

        var hex = level.toString(16);
        backgroundColor = "#ffff" + hex + hex;

        console.log(backgroundColor );

        if(level < 15){
            level += 1;
            setTimeout(step,100);
        }
    };
    setTimeout(step,100);
};

fade();

// ex 4
var add = function (nodes){
    var helper = function(i){
        return function(e){
            console.log(i);
        };
    };

    var i;
    for(i = 0; i < nodes.length; i++){
        nodes[i].onclick = helper(i);
    }
};
