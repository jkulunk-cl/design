var foo = function () {
    var a = 3, b = 5;

    var bar = function () {
        var b = 7, c = 11;
        console.log('2 ' + a + ' ' + b + ' ' + c );

        a += b + c;
        console.log('3 ' + a + ' ' + b + ' ' + c );
    };
    console.log('1 ' + a + ' ' + b + ' undefined' );
    
    bar();
    console.log('4 ' + a + ' ' + b + ' undefined' );
};

foo();