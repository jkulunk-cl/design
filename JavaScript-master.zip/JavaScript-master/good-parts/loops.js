var myObj = {
    first: 'amy',
    last: 'adams',
    title: 'actress'
};


// for
console.log('-- for loop');
for (i = 0; i < Object.keys(myObj).length; i++){
    console.log(i);
}


// for in
console.log('-- for in');
for (var prop in myObj){
    console.log(myObj[prop]);
}


// while

// do while
