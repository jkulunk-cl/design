var person = {
    first: 'amy',
    last: 'adams',
    full: function(){
        return this.first + ' ' + this.last;
    }
}

var anotherObj = {
    first: 'rachel',
    last: 'mcadams'
}

var out;

out = person.full.call(anotherObj);

console.log(out); // rachel mcadams

// apply or call invokes a method with the given this
//      apply accepts an array of args
//      call accepts an args list

