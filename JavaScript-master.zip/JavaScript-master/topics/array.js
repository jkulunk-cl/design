// ex 1
var colors = ['red', 'blue', 'green'];

colors.splice(2,0,'orange','yellow');

console.log(colors);

// ex 2. for each
// runs callback once on each item in array
var arr = ['a', 'b', 'c'];

arr.forEach(function(item){
    console.log(item);
});

// ex 3
var arr2 = [];
['d','e','f'].forEach(function(i){
    arr2[i] = undefined;
    
});

console.log(arr2);

//ex 4
var arr1 = 'john'.split('');
var arr2 = arr1.reverse();
var arr3 = 'jones'.split('');
arr2.push(arr3);

console.log(arr1);
console.log(arr2);
console.log(arr2.slice(-1)); //slice from end

// ex 5. map
var arr = [1,2,3];
var arrMap = arr.map(function(i){
    return i * 2;
})
console.log(arrMap);

// ex 6
var arr6 = [1,2,3,4,5,];
arr6.push('end');
arr6.unshift('begin');

console.log(arr6);