(function(){
    try {
        throw new Error();
    }
    catch(x) {
        var x = 1,
        y = 2;
        console.log('catch x: ' + x);   // this x is local
    }

    console.log('log x: ' + x);     // this x is global w/o value
    console.log('log y: ' + y);     // y is global

}());

// var statements are hoisted without initial values