console.log(1 + '2' + '3');
console.log(1 + + '2' + '3'); // order of operation. converts +'2' first, then 1 + 2
console.log(1 + -'1' + '2'); // order of operation. converts -"1" to -1, then add 1 equals 0
console.log(+'1' + '2' + '3'); // +'1' converts string to number
console.log('a' - 'b' + '3'); // NaN plus string
console.log('a' - 'b' + 3); // NaN plus num equals Nan