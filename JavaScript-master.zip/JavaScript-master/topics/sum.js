function sum(x){
    if(arguments.length == 2){
        return arguments[0] + arguments[1];
    }
    else {
        return function(y){
            return x + y;
        }
    }
}

console.log(sum(2,3));
console.log(sum(2)(3));

// alt
function sumAlt(x,y){
    if (y !== undefined){
        return x + y;
    }
    else {
        return function(y){
            return x + y;
        }
    }
}

console.log(sumAlt(2,3));
console.log(sumAlt(2)(3));

