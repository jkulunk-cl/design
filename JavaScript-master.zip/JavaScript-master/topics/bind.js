
// bind getName method to hero obj.
var hero = {
    name: 'capt archer',
    getName: function(){
        return this.name;
    }
}

var crew = hero.getName.bind(hero);

var out1 = crew();

var out2 = hero.getName();
console.log(out1);            // capt archer
console.log(out2);    // capt archer
// bind creates a new function. when called its this is set to the value provided
