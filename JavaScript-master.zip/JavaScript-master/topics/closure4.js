var list = [11,22,44,55];

for(var i = 0; i < list.length; i++){

    setTimeout((function(j){
        return function(){
            console.log(j);
        };
    }(i)), 3000);
}