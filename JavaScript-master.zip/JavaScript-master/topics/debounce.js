// debounce function. wraps event
function debounce(fn, delay){
    let timer = null;

    return function(){ // closure
        let context = this;
        let args = arguments;

        clearTimeout(timer); // reset timer
        timer = setTimeout(function(){
            fn.apply(context,args);
        }, delay);
    }
}

//// implementation

// called when scrolling
function foo(){
    console.log('scrolling event');
}

// wrap function in debounce, 2 sec delay
let elem = document.getElementById('container');
elem.addEventListener('scroll', debounce(foo,2000));