// ex NaN
var count = NaN

if (typeof count === 'number'){
    console.log(true); // type is a number
}

if (count !== NaN){
    console.log(true); // NaN !== NaN 
}

// ex floating point
console.log(0.1 + 0.2); // floating point number
console.log(0.1 + 0.2 == 0.3); // false

// is integer
var x = 0.5 + 0.5;

if (x === Math.round(x)){
    console.log(x + ' is an integer');
}
else {
    console.log(x + ' not an integer');
}