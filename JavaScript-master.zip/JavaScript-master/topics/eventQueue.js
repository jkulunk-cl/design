// event queue

(function(){
    console.log(1);             // first
    setTimeout(function(){
        console.log(2);         // fourth
    },1000);
    setTimeout(function(){      // third
        console.log(3);
    },0);
    console.log(4);             // second
}());

// in order 1,4,3,2
