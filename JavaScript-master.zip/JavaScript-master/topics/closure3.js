// https://coderbyte.com/algorithm/3-common-javascript-closure-questions
// question 2

function createBase(base){ // base is a private var
    return function(num){  // num is param passed into new addSix
        console.log(base + ' + ' + num);
        return base + num;  // returns private var + param
    }
}
var addSix = createBase(6);
addSix(10);
addSix(21);