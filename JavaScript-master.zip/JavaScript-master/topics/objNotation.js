// ex 1
var a = {},
    b = {key:'b'},
    c = {key:'c'}

a[b] = 123;
a[c] = 456;

console.log(a[b]); // returns 456
// because a[b] is same as a[c]
// b and c are now a string '[object object]'
console.log(a); // returns {'[object object]': 456}

// ex 2 clone an obj
// note. is a shallow copy. not nested.
var obj1 = {a:1, b:2};
var obj2 = Object.assign({}, obj1);

obj2.c = 3;
obj2['d'] = 4;

console.log(obj1);
console.log(obj2);