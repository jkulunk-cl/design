var list = [23,15,54,48];
var loop = function(){
    
        for (var i = 0; i < list.length; i++){
            
            setTimeout(function(){
                console.log(i + ' ' + list[i]);
            }, 3000);
            
        }
    
    
};

//loop();

var loop2 = function(){
    for (var i = 0; i < list.length; i++){
        setTimeout(function(j){
            return function(){
                console.log(j + ' ' + list[j]);
            }
        }(i),3000);
    }
}

//loop2();

var loop3 = function(){
    for (var i = 0; i < list.length; i++){
        setTimeout(function(j){
            return function(){
                console.log(j + ' ' + list[j]);
            }
        }(i), 3000);
    }
}

//loop3();

// remember
/* for(var i){ // for loop
    setTimeout(function(j){ // assign local var for i
        return function(){} // return current count
    }(i),3000); // iife. pass in count to new count
} */

for(var i = 0; i < list.length; i++){
    setTimeout(function(j){ // iiff
        return function(){  // closure
            console.log(j); // local scope
        }
    }(i),3000);
}
