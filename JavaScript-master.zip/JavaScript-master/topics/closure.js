// private counter
var add = (function(){
    var count = 0;
    return function() {
        return count++;
    }
}());

console.log(add());
console.log(add());
console.log(add());

// ex 2
// outer function passes 1 to anon func, assigns to x
// inner has scope to outer x
(function(x){
    return (function(y){
        console.log(x + ' ' + y);
    })('here')
})('there');

// ex 3
var globalVar = 'a';
(function outer(outerArg){
    var outerVar = 'b';

    (function inner(innerArg){
        var innerVar = 'c';

        console.log('globalVar: ' + globalVar);
        console.log('outerArg: ' + outerArg);
        console.log('outerVar: ' + outerVar);
        console.log('innerArg: ' + innerArg);
        console.log('innerArg: ' + innerVar);

    }('d'));
}('e'));