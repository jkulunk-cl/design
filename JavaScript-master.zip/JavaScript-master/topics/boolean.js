console.log(0 || 1); // 0 is false, but 1 is true
console.log(1 || 2); // 1 is true, ignore 2
console.log(0 && 1); // 0 is false, ignore 1
console.log(1 && 2); // 1 is true but returns expression (2)

console.log(false == '0'); // first converts type then compares values. 0 is false so equals true
console.log(false === '0'); // compares types and values. the string '0' is true so equals false
