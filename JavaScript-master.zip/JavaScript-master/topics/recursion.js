// ex 1
function countDown(n){
    console.log(n);
    if (n >= 1){
        countDown(n -1);
    }
}

//countDown(10);

// ex 2
// iife passing in 10 to n
console.log((function fact(n){
    console.log(n); 
    return ((n>1)? n * fact(n-1) : n)
})(10));

// ex 3
// prevent stack overflow if list is too large
// fix. send recursion to event loop instead of call stack. keeps call stack clear
var list = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20];

var nextItem = function(){
    var item = list.pop();

    if(item){
        console.log(item);  // or some process
        // nextItem();  original
        setTimeout(nextItem, 0) // fix
    }
};

nextItem();
