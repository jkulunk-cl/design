function debounce(fn, delay){
    var timer = null;
    return function(){
        var context = this;
        var args = arguments;

        clearTimeout(timer);

        timer = setTimeout(function(){
            fn.apply(context, args);
        }, delay);
    };
}

document.getElementById('btn').addEventListener('click', function(){
    debounce(function(e){
        console.log('click');
    },200);
})