var out;

var foo = {
    x:3
};


var bar = function(){
    console.log(this.x);
};

bar();

var bound = bar.bind(foo);

bound();
out = bound;
console.log(out);