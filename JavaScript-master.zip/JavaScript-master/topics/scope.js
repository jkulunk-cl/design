// ex 1
var length = 10;

function myFun(){
    console.log(this.length);
} 

var obj = {
    length: 5,
    method: function(myFun){
        myFun();
        arguments[0]();
    }
};

obj.method(myFun, 1);

// returns..
// undefined because this.length is local
// 2 because method receives 2 arguments

// ex 2
// hoisting
// Returns undefined. local x is hoisted to top of function but w/o initial value assignment
var x = 21;
var girl = function(){
    console.log(x);
    var x = 20;
};

girl();

// ex 3
// Because using let instead of var. i is local to for loop scope.
// returns 0-4, every 5 sec.
for (let i = 0; i < 5; i++){
    setTimeout(function(){
        console.log('let i:' + i);
    }, 1000 * i);
}

// ex scope
var myObject = {
    foo: 'bar',
    func: function(){
        var self = this;
        console.log('outer fun this.foo: ' + this.foo); // bar
        console.log('outer fun self.foo: ' + self.foo); // bar
        (function(){
            console.log('inner fun: ' + this.foo); // undefined. because this refers to anon function.
            console.log('inner fun: ' + self.foo); // bar. because self is in scope
        
        }());
    }
}

myObject.func();