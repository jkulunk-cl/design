var a = true;
	
var b = a || null;

console.log(b);

// var x = x || {};
// console.log(x);