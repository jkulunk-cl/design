'use strict';

function print(out) {
	str = out;			// throws error because of global var
	console.log(str);
}

print('yo');